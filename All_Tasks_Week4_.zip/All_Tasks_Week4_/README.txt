AI/ML INTERNSHIP — WEEK 4 SUBMISSION PACKAGE
Topic: Introduction to Machine Learning & Linear Regression
Deadline: 28th October 2026

CONTENTS
--------
1. Week4_LinearRegression_Report.docx  — full weekly report (English)
2. Week4_LinearRegression_Report.pdf   — PDF version of the report (submission format)
3. Week4_LinearRegression_Slides.pptx  — 13-slide presentation
4. Week4_LinearRegression_Notebook.ipynb — runnable notebook (Google Colab / Jupyter)
5. salary_dataset.csv                  — dataset (Experience vs Salary, 120 rows)
6. images/                             — 20 realistic figures used as evidence/screenshots:
   data preview, missing values, duplicates, statistics, histograms, boxplots,
   correlation heatmap, scatter plots, train-test split, regression line,
   actual vs predicted, residuals, MSE/R² metrics, prediction table, workflow
   diagram, prediction demo, summary dashboard
7. Reflection_Answers.txt              — answers to the 4 weekly reflection questions
8. Task_List_EN.txt                    — the weekly task list in English
9. LinkedIn_Post.txt                   — ready-to-post LinkedIn update

MODEL SUMMARY
-------------
Feature (X): YearsExperience | Target (y): Salary (USD)
Train/Test split: 80/20 (random_state=42)
Slope: ~9,330 USD/year | Intercept: ~26,086 USD
MSE: ~37 million | R²: 0.9613 → model performs very well
